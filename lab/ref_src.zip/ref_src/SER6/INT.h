/*
*========================================================================================================
*
* File    : INT.h
* Version : V3.0
* Modified  
* On	  : 201220223
* By      : Kuo-Yang Tu
*
*========================================================================================================
*/
#ifndef _INT_H_
#define _INT_H_


#include 	<inttypes.h>
#include 	<stdlib.h>
#include	<stdint.h>

#include	<avr/io.h>
#include	<util/delay.h>
#include	<avr/interrupt.h>

#include 	"MOTOR_CONTROL.h"

#define 	SETBIT(REG,BIT)	(REG |= (_BV(BIT)))
#define 	CLRBIT(REG,BIT)	(REG &= ~(_BV(BIT)))
#define 	CHKBIT(REG,BIT)	((REG & (_BV(BIT)))==(_BV(BIT)))

uint8_t		PWM = 0;
uint8_t		Menu = 0;
uint8_t		Move_ok = 1;
uint8_t		Menu_Counter = 0;

void init_Ex_INTn(void)
{
	//EICRA = (1<<ISC11)|(1<<ISC01);//|(1<<ISC00);	//[10]INT0���U��([11]INT0���W��)�u���ͫD�P�B���_�ШD
	EIMSK = (1<<INT7)|(1<<INT5)|(1<<INT4)|(1<<INT1)|(1<<INT0);	//INT0�~�����_�ШD�ϯ�
	DDRD = DDRD & 0xFC;
	PORTD = PORTD | 0x03;
	DDRE = DDRE & 0x4F;
	PORTE = PORTE | 0xB0;
}

ISR(INT0_vect)
{
	PORTG = 0x1F;
	CLRBIT(PORTG, PG0);	
	PWM = PWM + 5;
	if (PWM > 250)
	{
		PWM = 0;
	}	
	motion(STOP, 0);
	Menu_Counter = 0;
	Menu = 0;
	_delay_ms(100);	
	EIFR |= 0xFF;
}

ISR(INT1_vect)
{
	PORTG = 0x1F;
	CLRBIT(PORTG, PG1);
	if (Menu == 0)
	{
		motion(FORWARD, PWM);
	}
	if (++Menu_Counter > 50)
	{
		Menu = 1;
		Menu_Counter = 0;
		Move_ok = 1;
		LCD_CLR();
		motion(STOP, 0);
	}
	_delay_ms(100);	
	EIFR |= 0xFF;
}


ISR(INT4_vect)
{
	PORTG = 0x1F;
	CLRBIT(PORTG, PG2);
	if (Menu == 0)
	{
		motion(TURN_LEFT, PWM);
	}
	if (++Menu_Counter > 50)
	{
		Menu = 2;
		Menu_Counter = 0;
		Move_ok = 1;
		LCD_CLR();
		motion(STOP, 0);
	}
	_delay_ms(100);	
	EIFR |= 0xFF;
}

ISR(INT5_vect)
{
	PORTG = 0x1F;
	CLRBIT(PORTG, PG3);
	if (Menu == 0)
	{
		motion(BACKWARD, PWM);
	}
	if (++Menu_Counter > 50)
	{
		Menu = 3;
		Menu_Counter = 0;
		Move_ok = 1;
		LCD_CLR();
		motion(STOP, 0);
	}
	_delay_ms(100);	
	EIFR |= 0xFF;
}

ISR(INT7_vect)
{
	PORTG = 0x1F;
	CLRBIT(PORTG, PG4);
	if (Menu == 0)
	{
		motion(TURN_RIGHT, PWM);
	}
	if (++Menu_Counter > 50)
	{
		Move_ok = Move_ok * -1;
		Menu_Counter = 0;
		LCD_CLR();
		motion(0,0);
	}
	_delay_ms(100);	
	EIFR |= 0xFF;
}

#endif	/* _INT_H_ */
