/*
*========================================================================================================
*
* File    : SER5_2.c
* Version : V3.0
* Modified 
* On	  : 20220223
* By      : Kuo-Yang Tu
*
*========================================================================================================
*/
#ifndef		F_CPU
#define		F_CPU 16000000UL
#endif

#include 	<avr/io.h>
#include 	<avr/interrupt.h>
#include 	<util/delay.h>
#include 	<stdio.h>
#include 	<inttypes.h>
#include 	<stdlib.h>
#include	<stdint.h>

#define 	SETBIT(REG,BIT)	(REG |= (_BV(BIT)))
#define 	CLRBIT(REG,BIT)	(REG &= ~(_BV(BIT)))
#define 	CHKBIT(REG,BIT)	((REG & (_BV(BIT)))==(_BV(BIT)))

#include 	"4B_LCD.h"
#include 	"MOTOR_CONTROL.h"
#include 	"INT.h"

uint16_t 	Rx_flag = 0;
int16_t		Rx_checksum = 0;
int16_t		Rx_checksum1 = 0;
int16_t		ADCcheck = 0;
int32_t		ADCdata = 0;
int32_t		ADCdata0 = 0;
int32_t		ADCdata1 = 0;
int32_t		ADCdata2 = 0;
int32_t		ADCdata3 = 0;
uint8_t 	ADCflag = 0;
uint16_t 	Voltage = 0;
uint16_t 	Line_R = 0;
uint16_t 	Line_M = 0;
uint16_t 	Line_L = 0;
uint16_t 	Stop = 0;
uint16_t 	PWM_turn = 0;
uint16_t 	PWM_move = 0;

char i = 0;

/* Timer2 ����ǰt���_�A�ȡA2ms�w�� */
ISR(TIMER2_COMP_vect)
{ 
	if (++Rx_checksum > 499)
	{
		Rx_checksum1 =+ 1;
		Rx_checksum = 0;
		if (Rx_checksum1 > 4)
			Rx_checksum1 = 0;
	}
/*
	char i;
	PORTG = 0b00000001;
	for (i=0; i<10; i++)
	LCD_L_Delay();
	PORTG = 0b00000010;
	for (i=0; i<10; i++)
	LCD_L_Delay();
	PORTG = 0b00000100;
	for (i=0; i<10; i++)
	LCD_L_Delay();
	PORTG = 0b00001000;
	for (i=0; i<10; i++)
	LCD_L_Delay();
	PORTG = 0b00010000;
*/
		
	Voltage = ADCdata0 / 5 + 4; 
	Line_R = ADCdata1 * 9 / 11;
	Line_M = ADCdata2 * 9 / 11;
	Line_L = ADCdata3 * 9 / 11;
	PWM_turn = 185-Voltage;
	PWM_move = 185-Voltage;
		
	if (Menu < 5)
	{
		LCD_Set_Cursor(1,13);
		putsi(Rx_checksum1,3);
	}

	if ((Voltage < 135) && (OCR1A == 0 || OCR1B == 0))
 	{
		motion(STOP, 0);
		PWM = 0;
		Menu = 0;
	}
	if (Menu == 1 && Voltage > 135)
 	{
		if (Move_ok == 1)
 		{		
			motion(STOP, 0);
		}
		else if (Move_ok > 1)
 		{		
			if (Line_R < 300)
 			{		
				motion(TURN_RIGHT, PWM_turn);
				Stop = 0;
			}
			else if (Line_L < 300)
 			{		
				motion(TURN_LEFT, PWM_turn);
				Stop = 0;
			}
			else if (Line_M < 300)
 			{		
				motion(FORWARD, PWM_move);
				Stop = 0;
			}
			else
			{		
				Stop++;
			}

			if(Stop > 80)
			{
				motion(BACKWARD, PWM_move);
				Stop++;
				if(Stop > 100 && Stop < 105)
				{
					motion(STOP, 0);
				}
				else if(Stop > 105)
				{
					motion(TURN_RIGHT, PWM_turn);
					Stop = 0;
				}			
			}
		}
	}

	TCNT2 = 120;	// reset Timer Count Register

}	//ISR T2

/* Time2 ���_�]�w */
void init_Ex_time2(void)
{
// (CL_1)  
	TCCR2 = (1<<CS22)|(1<<CS20); 	// Timer Clock = system clock / 1024
// 16000000/1024=15625=15.625KHz
// 2ms*15.625KHz-1=30.25->31
// 10ms*15.625KHz-1=155.25->156
// 5ms*15.625KHz-1=77.125->78

// (CL_2.0)
	TIFR  = 1<<OCF2;				// Clear OCF2 / Clear pending interrupts
// (CL_2.1)
	TIMSK = 1<<OCIE2;				// Enable Timer 2 Output Compare Match Event Interrupt

	TCNT2 = 120;	//256-31=225  256-78=178
}

/* ADC �]�w */
void adcInit(void)
{
	ADMUX=(1<<REFS0); //�Ѧҹq���ϥ�AVCC�A���G�q�{�k����A�q�D��ADC1
		//0110 0000 |(1<<MUX0)|(1<<ADLAR)

	ADCSRA=(1<<ADEN)|(1<<ADSC)|(1<<ADFR)|(1<<ADIE|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0)); //�s���ഫ�Ҧ��A���_�ɯ�A64���W
		//1110 1110Ƶ|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0)
}

/*
*-------------------------------------------------------------------------------------------------------
*
*	ADC��ƨ�s��ơ]���_�^
*	ADC_vect�OADC���_���V�q�����w�q
*	ISR_BLOCK��GCC interrupt.h�w�����_�Ѽ�
* 
*-------------------------------------------------------------------------------------------------------
*/
ISR(ADC_vect) //,ISR_BLOCK
{
	if (ADCflag == 0)
	{
		ADCdata = ADCL;
		ADCdata += ((unsigned int) ADCH << 8);
		if (++ADCcheck > 3)
		{
			ADCdata0 = ADCdata;
			ADMUX=(1<<REFS0)|(1<<MUX0);	//ADC1
			ADCcheck = 0;
			ADCflag = 1;
		}
	}
	else if (ADCflag == 1)
	{
		ADCdata = ADCL;
		ADCdata += ((unsigned int) ADCH << 8);
		if (++ADCcheck > 3)
		{
			ADCdata1 = ADCdata;
			ADMUX=(1<<REFS0)|(1<<MUX1);	//ADC2
			ADCcheck = 0;
			ADCflag = 2;
		}
	}
	else if (ADCflag == 2)
	{
		ADCdata = ADCL;
		ADCdata += ((unsigned int) ADCH << 8);
		if (++ADCcheck > 3)
		{
			ADCdata2 = ADCdata;
			ADMUX=(1<<REFS0)|(1<<MUX1)|(1<<MUX0);	//ADC3
			ADCcheck = 0;
			ADCflag = 3;
		}
	}
	else if (ADCflag == 3)
	{
		ADCdata = ADCL;
		ADCdata += ((unsigned int) ADCH << 8);
		if (++ADCcheck > 3)
		{
			ADCdata3 = ADCdata;
			ADMUX=(1<<REFS0);			//ADC0
			ADCcheck = 0;
			ADCflag = 0;
		}
	}
	
	if (++Rx_checksum1 > 999)
	{
		Rx_checksum1 = 0;
	}			
}

void forward (uint8_t speed) {
	CLRBIT(PORTB, PB2);
	SETBIT(PORTB, PB3);
	CLRBIT(PORTB, PB0);
	SETBIT(PORTB, PB1);
	OCR1A = speed*4;
	OCR1B = speed*4;
}

void reverse (uint8_t speed) {
	CLRBIT(PORTB, PB3);
	SETBIT(PORTB, PB2);
	CLRBIT(PORTB, PB1);
	SETBIT(PORTB, PB0);
	OCR1A = speed*4;
	OCR1B = speed*4;
}
//-----------------------------------------------
//               main function
//-----------------------------------------------
int main (void)
{
 	/* For PWM */
	DDRB = 0xFF;
	DDRE = 0x1F;

	/* For LED */
	DDRG = 0x1F;
	PORTG = 0x1F;

	/* LCD ��l�� */
 	OpenLCD();

	/* LCD ���Y��� */
	LCD_Set_Cursor(0,3);	//�]�wXY�y�ЩM�_�l��l 	           
	putsLCD("TAIBOTICS");	//��J�r��

	LCD_Set_Cursor(1,5);	           
	putsLCD("ROBOT");
	
	_delay_ms(2000);
	
	LCD_CLR();
				
	LCD_Set_Cursor(0,0);         
	putsLCD("L");		

	LCD_Set_Cursor(0,4) ;               
	putsLCD("M");

	LCD_Set_Cursor(0,8) ;               
	putsLCD("R");

	LCD_Set_Cursor(0,12) ;               
	putsLCD("P");

	LCD_Set_Cursor(1,0) ;
	putsLCD("V");	

	LCD_Set_Cursor(1,4) ;               
	putsLCD("R");

	LCD_Set_Cursor(1,8) ;               
	putsLCD("L");

	LCD_Set_Cursor(1,12) ;               
	putsLCD("C");	

	/* PWM1 ��l�� */
	init_PWM_time1();	

	/* PWM3 ��l�� */
	//init_PWM_time3();

 	/* T/C2 ��l�� */
	init_Ex_time2();
	
	/* ADC ��l�� */
	adcInit();

	/* INT ��l�� */
	init_Ex_INTn();

	Menu = 0;
	
	//forward(100);
	//reverse(100);

	//motion(FORWARD, 100);

	//Menu = 1;
	//Move_ok = 2;

	sei();


	while(1)
 	{
 		_delay_ms(10);		

		cli();

		if (Menu == 0)
		{
			if (Menu_Counter == 0)
			{
				LCD_CLR();
				
				LCD_Set_Cursor(0,0);         
				putsLCD("L");		

				LCD_Set_Cursor(0,4) ;               
				putsLCD("M");

				LCD_Set_Cursor(0,8) ;               
				putsLCD("R");

				LCD_Set_Cursor(0,12) ;               
				putsLCD("P");

				LCD_Set_Cursor(1,0) ;
				putsLCD("V");	

				LCD_Set_Cursor(1,4) ;               
				putsLCD("R");

				LCD_Set_Cursor(1,8) ;               
				putsLCD("L");

				LCD_Set_Cursor(1,12) ;               
				putsLCD("C");
			
				Menu_Counter = 1;
			}

			LCD_Set_Cursor(0,1);               
			putsi(Line_R,3);
		
			LCD_Set_Cursor(0,5);
			putsi(Line_M,3);

			LCD_Set_Cursor(0,9);
			putsi(Line_L,3);

			LCD_Set_Cursor(0,13);
			putsi(PWM,3);

			LCD_Set_Cursor(1,1);               
			putsi(Voltage,3);

			LCD_Set_Cursor(1,5);
			putsi(OCR0,3);

			LCD_Set_Cursor(1,9);
			putsi(OCR2,3);
			
		}
		else if (Menu == 1)
 		{
			LCD_Set_Cursor(0,0);	       
			putsLCD("M1:");
				
			LCD_Set_Cursor(0,3) ;
			putsLCD("V");

			LCD_Set_Cursor(0,4);               
			putsi(Voltage,3);

			if (Move_ok == 1)
			{
				LCD_Set_Cursor(0,8) ;               
				putsLCD("off");
			}
			else
			{
				LCD_Set_Cursor(0,8) ;               
				putsLCD("on");
			}			

			LCD_Set_Cursor(0,12) ;               
			putsLCD("P");

			LCD_Set_Cursor(0,13);
			putsi(PWM,3);

			LCD_Set_Cursor(1,0);	          
			putsLCD("L");		

			LCD_Set_Cursor(1,4) ;               
			putsLCD("M");

			LCD_Set_Cursor(1,8) ;               
			putsLCD("R");		

			LCD_Set_Cursor(1,1);               
			putsi(Line_R,3);
		
			LCD_Set_Cursor(1,5);
			putsi(Line_M,3);

			LCD_Set_Cursor(1,9);
			putsi(Line_L,3);

			LCD_Set_Cursor(1,12) ;               
			putsLCD("C");

		}
		else if (Menu == 2)
 		{
			LCD_Set_Cursor(0,0);	       
			putsLCD("M2:");
				
			LCD_Set_Cursor(0,3) ;
			putsLCD("V");

			LCD_Set_Cursor(0,4);               
			putsi(Voltage,3);

			if (Move_ok == 1)
			{
				LCD_Set_Cursor(0,8) ;               
				putsLCD("off");
			}
			else
			{
				LCD_Set_Cursor(0,8) ;               
				putsLCD("on");
			}

			LCD_Set_Cursor(0,12) ;               
			putsLCD("P");

			LCD_Set_Cursor(0,13);
			putsi(PWM,3);

			LCD_Set_Cursor(1,12) ;               
			putsLCD("C");
		}
		else if (Menu == 3)
 		{
			LCD_Set_Cursor(0,0);	       
			putsLCD("M3:");
				
			LCD_Set_Cursor(0,3) ;
			putsLCD("V");

			LCD_Set_Cursor(0,4);               
			putsi(Voltage,3);

			if (Move_ok == 1)
			{
				LCD_Set_Cursor(0,8) ;               
				putsLCD("off");
			}
			else
			{
				LCD_Set_Cursor(0,8) ;               
				putsLCD("on");
			}

			LCD_Set_Cursor(0,12) ;               
			putsLCD("P");

			LCD_Set_Cursor(0,13);
			putsi(PWM,3);

			LCD_Set_Cursor(1,12) ;               
			putsLCD("C");
		}
		else if (Menu == 5)
 		{
			LCD_Set_Cursor(0,0);	       
			putsLCD("Battery is dead!");
				
			LCD_Set_Cursor(1,0) ;
			putsLCD("Please Change BT");			
		}
		sei();		    
	}//while
   	
}//main	



