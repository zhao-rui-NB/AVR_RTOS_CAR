/*
*========================================================================================================
*
* File    : MOTOR_CONTROL.h for SER3
* Version : V3.0
* Modified  
* On	  : 20220223
* By      : Kuo-Yang Tu
*
*========================================================================================================
*/
#ifndef _MOTOR_CONTROL_H_
#define _MOTOR_CONTROL_H_

#define STOP 		0
#define FORWARD 	1
#define TURN_LEFT 	2
#define BACKWARD	3
#define TURN_RIGHT 	4


/* Time1 PWM �]�w */
void 
init_PWM_time1(void)
{
	TCCR1A=(1<<COM1A1)|(1<<WGM11)|(1<<WGM10);
	TCCR1B=(1<<WGM12)|(1<<CS12); 	
	TCCR1C=(1<<FOC1A);
	OCR1A = 0;	//PB5(OC1A)
}

/* Time3 PWM �]�w */
void 
init_PWM_time3(void)
{
	TCCR3A=(1<<COM3A1)|(1<<COM3B1)|(1<<WGM31)|(1<<WGM30);
	TCCR3B=(1<<WGM32)|(1<<CS32); 	
	TCCR3C=(1<<FOC3A)|(1<<FOC3B);
	OCR3A = 0;	//PE3(OC3A)(MOTOR_L)
	OCR3B = 0;	//PE4(OC3B)(MOTOR_R)
	CLRBIT(PORTB, PB0);
	SETBIT(PORTB, PB1);
	CLRBIT(PORTB, PB2);
	SETBIT(PORTB, PB3);
}

/* �ʦV�P�_ */
void 
motion(uint8_t dir,uint8_t speed)
{
	if (dir == STOP)
	{
		OCR3A = 0;
		OCR3B = 0;
	}
	else if (dir == FORWARD)
	{
		CLRBIT(PORTB, PB0);
		SETBIT(PORTB, PB1);
		CLRBIT(PORTB, PB2);
		SETBIT(PORTB, PB3);
		OCR3A = speed*3;
		OCR3B = speed*3;
	}
	else if (dir == TURN_LEFT)
	{
		CLRBIT(PORTB, PB0);
		SETBIT(PORTB, PB1);
		CLRBIT(PORTB, PB3);
		SETBIT(PORTB, PB2);
		OCR3A = speed*3;
		OCR3B = speed*3;
	}
	else if (dir == BACKWARD)
	{
		CLRBIT(PORTB, PB1);
		SETBIT(PORTB, PB0);
		CLRBIT(PORTB, PB3);
		SETBIT(PORTB, PB2);
		OCR3A = speed*3;
		OCR3B = speed*3;
	}
	else if (dir == TURN_RIGHT)
	{
		CLRBIT(PORTB, PB1);
		SETBIT(PORTB, PB0);
		CLRBIT(PORTB, PB2);
		SETBIT(PORTB, PB3);
		OCR3A = speed*3;
		OCR3B = speed*3;
	}

}

#endif /* _MOTOR_CONTROL_H_ */
