#ifndef __SERIAL_H__
#define __SERIAL_H__

#include "kernel.h"

#include <avr/io.h>

// 1000000
#define USART0_BAUD_RATE 1
#define USART0_RX_BUFFER_SIZE 8
#define RS485_RX PORTE &= ~(1 << PE2); PORTE |= (1 << PE3)
#define RS485_TX PORTE &= ~(1 << PE3); PORTE |= (1 << PE2)

// 115200
#define USART1_BAUD_RATE 16
// 57600
//#define USART1_BAUD_RATE 34
// 9600
//#define USART1_BAUD_RATE 207
#define USART1_RX_BUFFER_SIZE 32

extern volatile uint8_t usart0_rx_buffer[];
extern volatile uint8_t usart0_rx_buffer_length;
extern Semaphore usart0_lock;
extern volatile uint8_t usart1_rx_buffer[];
extern volatile uint8_t usart1_rx_buffer_length;
extern Semaphore usart1_lock;

uint8_t reply_status;

enum ReplyStatus {
	
	REPLY_OFF,
	REPLY_ON

};

void initRS485(void);
void initUSART0(void);
void initUSART1(void);

void transmitBufferUSART0(uint8_t const buffer[], uint8_t buffer_length);
void transmitBufferUSART1(uint8_t const buffer[], uint8_t buffer_length);
void transmitStringUSART1(char *msg);

static inline uint8_t getReplyStatus(void) { return reply_status; };
static inline void setReplyStatus(uint8_t status) { reply_status = status; };

#endif
