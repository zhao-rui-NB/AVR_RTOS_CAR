#ifndef __STATE_H__
#define __STATE_H__

#include "ax12motor.h"
#include "kernel.h"

#include <stdint.h>

/*// proportional 1.0 fixed point
#define KP 32
// integral -0.1 fixed point
#define KI -3
// integral windup minimum -128 fixed point
#define MIN_I -4096
// integral windup maximum 128 fixed point
#define MAX_I 4096
// derivative -0.1 fixed point
#define KD -3*/

struct state {

	int16_t load[NUMBER_OF_SERVOS];
	uint8_t position[NUMBER_OF_SERVOS];

	Semaphore lock;

	int8_t compensation_matrix[NUMBER_OF_SERVOS];
	int8_t compensation[NUMBER_OF_SERVOS];
	int8_t update_vector[3];

};

typedef struct state State;

extern volatile State robot_state;
extern volatile uint8_t reset_motion[];

enum Direction {

	DIRECTION_CW = 1,
	DIRECTION_CCW = 2

};

enum ResetMotion {

	RESET_FRONT = 9,
	RESET_BACK = 10

};

void initState(void);
void calculateCompensation(void);
//int16_t pid(uint8_t id);
void readLoad(uint8_t id);
void resetLoad(void);
void transmitLoad(uint8_t id);
void reset(void *arg);

static inline uint8_t loadDirection(uint16_t current) { return ( current & (1 << 10) ) >> 8; };

#endif
