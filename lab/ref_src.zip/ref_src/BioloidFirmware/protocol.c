#include "protocol.h"
#include "serial.h"

uint8_t protocolCheckSum(uint8_t const buffer[], uint8_t buffer_length) {

	uint16_t result = 0;

	for (uint8_t x = 0; x < buffer_length; x++)
		result += buffer[x];

	return (uint8_t) (result & 0x7f);

} // protocolCheckSum

void protocolSuccess(void) {

	uint8_t reply[3];

	reply[0] = CMD_HEADER;
	reply[1] = 0;
	reply[2] = protocolCheckSum(&reply[1], 1);

	downSemaphore(&usart1_lock);
	transmitBufferUSART1(reply, 3);
	upSemaphore(&usart1_lock);
	
	/*uint8_t reply[8];

	reply[0] = 'a';
	reply[1] = 'b';
	reply[2] = 'c';
	reply[3] = 'd';
	reply[4] = 'e';
	reply[5] = 'f';
	reply[6] = 'g';
	reply[7] = 'h';

	downSemaphore(&usart1_lock);
	transmitBufferUSART1(reply, 8);
	upSemaphore(&usart1_lock);*/
	

} // protocolSuccess

void protocolFail(void) {

	uint8_t reply[3];

	reply[0] = CMD_HEADER;
	reply[1] = 1;
	reply[2] = protocolCheckSum(&reply[1], 1);

	downSemaphore(&usart1_lock);
	transmitBufferUSART1(reply, 3);
	upSemaphore(&usart1_lock);

} // protocolFail
