#include "state.h"
//#include "fixed_point.h"
#include "motion.h"
#include "protocol.h"
#include "serial.h"
#include "timer.h"
#include "led.h"
#include <util/delay.h>

volatile State robot_state;
volatile uint8_t reset_motion[2];

void initState(void) 
{
  /* uint8_t i; */

#if 0
  for(;;)
    {
      //      transmitStringUSART1("init state loop\n");
      changeLED(PLAY_LED, LED_TOGGLE);
      for( i = 0; i < 200; i++ )
	{
	  _delay_ms(100);
	}
    }
#endif

  initSemaphore( (Semaphore *) &robot_state.lock, 1 );
  
  downSemaphore( (Semaphore *) &robot_state.lock );
  
  for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++)
    robot_state.position[x] = getPosition(x + 1, REPLY_OFF);
  
  // test
  //writeByte(LEFT_SHOULDER_LATERAL, AX12MOTOR_CW_COMPLIANCE_MARGIN, 16, REPLY_OFF);
  //writeByte(LEFT_SHOULDER_LATERAL, AX12MOTOR_CCW_COMPLIANCE_MARGIN, 16, REPLY_OFF);
  //writeByte(RIGHT_SHOULDER_LATERAL, AX12MOTOR_CW_COMPLIANCE_MARGIN, 16, REPLY_OFF);
  //writeByte(RIGHT_SHOULDER_LATERAL, AX12MOTOR_CCW_COMPLIANCE_MARGIN, 16, REPLY_OFF);
  
  // frontal
  robot_state.compensation_matrix[LEFT_SHOULDER_FRONTAL_INDEX] = 0;
  robot_state.compensation_matrix[LEFT_ELBOW_FRONTAL_INDEX] = 0;
  // left + right -
  robot_state.compensation_matrix[LEFT_HIP_FRONTAL_INDEX] = 0;//-1;
  // left + right -
  robot_state.compensation_matrix[LEFT_ANKLE_FRONTAL_INDEX] = -1;
  // left - right +
  robot_state.compensation_matrix[RIGHT_SHOULDER_FRONTAL_INDEX] = 0;
  // left - right +
  robot_state.compensation_matrix[RIGHT_ELBOW_FRONTAL_INDEX] = 0;
  // left + right -
  robot_state.compensation_matrix[RIGHT_HIP_FRONTAL_INDEX] = 0;//-1;
  // left + right -
  robot_state.compensation_matrix[RIGHT_ANKLE_FRONTAL_INDEX] = -1;
  
  // lateral
  // backward + forward -
  robot_state.compensation_matrix[LEFT_SHOULDER_LATERAL_INDEX] = 0;//-1;
  // backward - forward +
  robot_state.compensation_matrix[LEFT_HIP_LATERAL_INDEX] = 1;
  // backward 
  robot_state.compensation_matrix[LEFT_KNEE_LATERAL_INDEX] = 0;
  // backward + forward -
  robot_state.compensation_matrix[LEFT_ANKLE_LATERAL_INDEX] = 0;//-1;
  // backward - forward +
  robot_state.compensation_matrix[RIGHT_SHOULDER_LATERAL_INDEX] = 0;//1;
  // backward + forward -
  robot_state.compensation_matrix[RIGHT_HIP_LATERAL_INDEX] = -1;
  robot_state.compensation_matrix[RIGHT_KNEE_LATERAL_INDEX] = 0;
  // backward - forward +
  robot_state.compensation_matrix[RIGHT_ANKLE_LATERAL_INDEX] = 0;//1;
  
  // traverse
  robot_state.compensation_matrix[LEFT_TORSO_TRAVERSE_INDEX] = 1;
  robot_state.compensation_matrix[RIGHT_TORSO_TRAVERSE_INDEX] = 1;
  
  upSemaphore( (Semaphore *) &robot_state.lock );
  
} // initState

// send x
// backward - forward +
// send y
// left - right +
// send z
void calculateCompensation(void) 
{
  
  /*robot_state.update_vector[0] = (robot_state.update_vector[0] == 0x7f ? 0 : robot_state.update_vector[0]);
    robot_state.update_vector[1] = (robot_state.update_vector[1] == 0x7f ? 0 : robot_state.update_vector[1]);
    robot_state.update_vector[2] = (robot_state.update_vector[2] == 0x7f ? 0 : robot_state.update_vector[2]);*/
  
  // frontal
  robot_state.compensation[LEFT_SHOULDER_FRONTAL_INDEX] = robot_state.compensation_matrix[LEFT_SHOULDER_FRONTAL_INDEX] * robot_state.update_vector[1];
  robot_state.compensation[LEFT_ELBOW_FRONTAL_INDEX] = robot_state.compensation_matrix[LEFT_ELBOW_FRONTAL_INDEX] * robot_state.update_vector[1];
  // left - right +
  robot_state.compensation[LEFT_HIP_FRONTAL_INDEX] = robot_state.compensation_matrix[LEFT_HIP_FRONTAL_INDEX] * robot_state.update_vector[1];
  robot_state.compensation[LEFT_ANKLE_FRONTAL_INDEX] = robot_state.compensation_matrix[LEFT_ANKLE_FRONTAL_INDEX] * robot_state.update_vector[1];
  robot_state.compensation[RIGHT_SHOULDER_FRONTAL_INDEX] = robot_state.compensation_matrix[RIGHT_SHOULDER_FRONTAL_INDEX] * robot_state.update_vector[1];
  robot_state.compensation[RIGHT_ELBOW_FRONTAL_INDEX] = robot_state.compensation_matrix[RIGHT_ELBOW_FRONTAL_INDEX] * robot_state.update_vector[1];
  // left - right +
  robot_state.compensation[RIGHT_HIP_FRONTAL_INDEX] = robot_state.compensation_matrix[RIGHT_HIP_FRONTAL_INDEX] * robot_state.update_vector[1];
  robot_state.compensation[RIGHT_ANKLE_FRONTAL_INDEX] = robot_state.compensation_matrix[RIGHT_ANKLE_FRONTAL_INDEX] * robot_state.update_vector[1];
  
  // lateral
  robot_state.compensation[LEFT_SHOULDER_LATERAL_INDEX] = robot_state.compensation_matrix[LEFT_SHOULDER_LATERAL_INDEX] * robot_state.update_vector[0];
  // backward - forward +
  robot_state.compensation[LEFT_HIP_LATERAL_INDEX] = robot_state.compensation_matrix[LEFT_HIP_LATERAL_INDEX] * robot_state.update_vector[0];
  robot_state.compensation[LEFT_KNEE_LATERAL_INDEX] = robot_state.compensation_matrix[LEFT_KNEE_LATERAL_INDEX] * robot_state.update_vector[0];
  // backward + forward -
  robot_state.compensation[LEFT_ANKLE_LATERAL_INDEX] = robot_state.compensation_matrix[LEFT_ANKLE_LATERAL_INDEX] * robot_state.update_vector[0];
  robot_state.compensation[RIGHT_SHOULDER_LATERAL_INDEX] = robot_state.compensation_matrix[RIGHT_SHOULDER_LATERAL_INDEX] * robot_state.update_vector[0];
  // backward + forward -
  robot_state.compensation[RIGHT_HIP_LATERAL_INDEX] = robot_state.compensation_matrix[RIGHT_HIP_LATERAL_INDEX] * robot_state.update_vector[0];
  robot_state.compensation[RIGHT_KNEE_LATERAL_INDEX] = robot_state.compensation_matrix[RIGHT_KNEE_LATERAL_INDEX] * robot_state.update_vector[0];
  // backward - forward +
  robot_state.compensation[RIGHT_ANKLE_LATERAL_INDEX] = robot_state.compensation_matrix[RIGHT_ANKLE_LATERAL_INDEX] * robot_state.update_vector[0];
  
  // traverse
  robot_state.compensation[LEFT_TORSO_TRAVERSE_INDEX] = robot_state.compensation_matrix[LEFT_TORSO_TRAVERSE_INDEX] * robot_state.update_vector[2];
  robot_state.compensation[RIGHT_TORSO_TRAVERSE_INDEX] = robot_state.compensation_matrix[RIGHT_TORSO_TRAVERSE_INDEX] * robot_state.update_vector[2];
  
  /*if (robot_state.update_vector[2] < 0) {
    
    robot_state.compensation[LEFT_TORSO_TRAVERSE_INDEX] = robot_state.compensation_matrix[LEFT_TORSO_TRAVERSE_INDEX] * robot_state.update_vector[2];
    robot_state.compensation[RIGHT_TORSO_TRAVERSE_INDEX] = 0;
    
    
    } else {
    
    robot_state.compensation[RIGHT_TORSO_TRAVERSE_INDEX] = robot_state.compensation_matrix[RIGHT_TORSO_TRAVERSE_INDEX] * robot_state.update_vector[2];
    robot_state.compensation[LEFT_TORSO_TRAVERSE_INDEX] = 0;
    
    
    }*/
  
  
  
} // calculateCompensation

/*int16_t pid(uint8_t id) {
  
  static int16_t integral[NUMBER_OF_SERVOS];
  static int16_t prev_error[NUMBER_OF_SERVOS];
  
  id--;
  
  int16_t error = fpInt(load[id] / 32);
  
  integral[id] = fpAdd(integral[id], error);
  
  if (integral[id] < MIN_I)
  integral[id] = MIN_I;
  else if (integral[id] > MAX_I)
  integral[id] = MAX_I;
  
  int16_t p = fpMul(KP, error);
  int16_t i = fpMul(KI, integral[id]);
  int16_t d = fpMul( KD, fpSub(error, prev_error[id]) );
  prev_error[id] = error;
  
  return fpRealI( fpAdd( p, fpAdd(i, d) ) );
  
  } // pid*/

void readLoad(uint8_t id) 
{
  
  downSemaphore( (Semaphore *) &robot_state.lock );
  
  uint16_t current = getLoad(id--, REPLY_OFF);
  
  // CW
  if (loadDirection(current) != 0)
    robot_state.load[id] = current & 0x3ff;
  
  // CCW
  else
    robot_state.load[id] = (current & 0x3ff) * -1;
  
  upSemaphore( (Semaphore *) &robot_state.lock );
  
} // readLoad

void resetLoad(void) 
{
  
  for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++)
    robot_state.load[x] = 0;
  
} // resetLoad

void transmitLoad(uint8_t id) 
{
  
  uint8_t c[3];
  
  downSemaphore(&usart1_lock);
  
  c[0] = id--;
  c[1] = (uint8_t) (robot_state.load[id] >> 8);
  c[2] = (uint8_t) robot_state.load[id];
  transmitBufferUSART1(c, 3);
  
  upSemaphore(&usart1_lock);
  
} // transmitLoad

void reset(void *arg) 
{
  
  downSemaphore(&usart1_lock);
  reset_motion[0] = *( (uint8_t *) arg );
  reset_motion[1] = *( (uint8_t *) (arg+1) );
  upSemaphore(&usart1_lock);
  
  /*uint16_t start_time = ticks3;
    uint8_t fall_detected = 0;
    
    while ( (ticks3 - start_time) < 100 ) 
    {
    
    readLoad(1);
    readLoad(2);
    transmitLoad(1);
    //transmitLoad(2);
    
    downSemaphore( (Semaphore *) &robot_state.lock );
    
    if ( ( reset_motion[0] == RESET_FRONT && ( robot_state.load[0] >= 512 || robot_state.load[1] <= -512 ) ) 
    || ( reset_motion[0] == RESET_BACK && ( robot_state.load[0] <=
    -512 || robot_state.load[1] >= 512 ) ) ) 
    {
    
    fall_detected = 1;
    startTask( (void *) &playMotion, (void *) reset_motion, MAXIMUM_PRIORITY, MAXIMUM_STACK_SIZE );
    break;
    
    }
    
    upSemaphore( (Semaphore *) &robot_state.lock );
    
    switch(reset_motion[0]) 
    {
    
    case RESET_FRONT:
    setPositionAndSpeed(1, 75, 8, REPLY_OFF);
    setPositionAndSpeed(2, 180, 8, REPLY_OFF);
    break;
    
    case RESET_BACK:
    setPositionAndSpeed(1, 15, 8, REPLY_OFF);
    setPositionAndSpeed(2, 250, 8, REPLY_OFF);
    break;
    
    default:
    break;
    
    }
    
    }
    
    if (!fall_detected)
    protocolSuccess();*/
  
  startTask( (void *) &playMotion, (void *) reset_motion, MAXIMUM_PRIORITY, MAXIMUM_STACK_SIZE );
  
} // reset
