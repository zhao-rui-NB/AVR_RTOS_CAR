#ifndef __LED_H__
#define __LED_H__

#include <avr/io.h>

typedef enum
  {
    PLAY_LED = (1 << PC6),
    PROGRAM_LED = (1 << PC5),
    MANAGE_LED = (1 << PC4),
    AUX_LED = (1 << PC3),
    RXD_LED = (1 << PC2),
    TXD_LED = (1 << PC1),
    POWER_LED = (1 << PC0)
  } LEDs;

typedef enum
  {
    LED_ON = 0,
    LED_OFF,
    LED_TOGGLE
  } LED_STATE;

static inline void
changeLED( LEDs led, LED_STATE state )
{
  if ( state == LED_ON )
    {
      PORTC = PORTC & (~ led );
    }
  else if ( state == LED_OFF )
    {
      PORTC = PORTC | led;
    }
  else if ( state == LED_TOGGLE )
    {
      PORTC = PORTC ^ led;
    }
}
    
void initLEDs(void);
static inline void playLEDOn(void) { PORTC &= ~(1 << PC6); }
static inline void playLEDOff(void) { PORTC |= (1 << PC6); }
static inline void programLEDOn(void) { PORTC &= ~(1 << PC5); }
static inline void programLEDOff(void) { PORTC |= (1 << PC5); }
static inline void manageLEDOn(void) { PORTC &= ~(1 << PC4); }
static inline void manageLEDOff(void) { PORTC |= (1 << PC4); }
static inline void auxLEDOn(void) { PORTC &= ~(1 << PC3); }
static inline void auxLEDOff(void) { PORTC |= (1 << PC3); }
static inline void rxdLEDOn(void) { PORTC &= ~(1 << PC2); }
static inline void rxdLEDOff(void) { PORTC |= (1 << PC2); }
static inline void txdLEDOn(void) { PORTC &= ~(1 << PC1); }
static inline void txdLEDOff(void) { PORTC |= (1 << PC1); }
static inline void powerLEDOn(void) { PORTC &= ~(1 << PC0); }
static inline void powerLEDOff(void) { PORTC |= (1 << PC0); }

#endif
