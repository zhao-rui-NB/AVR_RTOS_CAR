#include "adc.h"
#include "kernel.h"
#include "led.h"
#include "serial.h"
#include "state.h"
#include "timer.h"

#include <avr/interrupt.h>
#include <util/delay.h>

int 
main(void) 
{
  /* uint8_t i; */

  initLEDs();
  initRS485();
  initUSART0();
  initUSART1();

  initKernel();
  //initState();
  //initUpButton();
  initTimer3();
  initTimer1();

  playLEDOn();

  startTask( (void *) &initState, 0, MINIMUM_PRIORITY, MINIMUM_STACK_SIZE );
  //startTask( (void *) &testAccelerometer, 0, MEDIUM_PRIORITY, MINIMUM_STACK_SIZE );

  // enable interrupts
  sei();

#if 0
  for(;;)
    {
      //      transmitStringUSART1("main loop\n");
      changeLED(PROGRAM_LED, LED_TOGGLE);
      for( i = 0; i < 200; i++ )
	{
	  _delay_ms(100);
	}
    }
#endif

  for(;;);
  return 0;

} // main
