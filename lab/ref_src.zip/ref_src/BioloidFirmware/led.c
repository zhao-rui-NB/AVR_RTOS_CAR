#include "led.h"

void 
initLEDs(void) 
{
  // set data direction output
  DDRC = DDRC | ( (1 << DDC6) | (1 << DDC5) | (1 << DDC4) | (1 << DDC3) | (1 << DDC2) | (1 << DDC1) | (1 << DDC0) );
} // initLEDs
