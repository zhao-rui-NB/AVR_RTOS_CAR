#include "motion.h"
#include "interpolation.h"
#include "protocol.h"
#include "serial.h"
#include "state.h"
#include "timer.h"

#include <avr/eeprom.h>
#include <avr/interrupt.h>

volatile uint8_t motion_buffer[MOTION_BUFFER_SIZE];
volatile uint16_t motion_buffer_length;
volatile uint8_t motion_buffer_page;
volatile uint8_t motion_stop;

volatile uint8_t home_position[POSITION_SIZE] = {3, 50, 205, 56, 201, 127, 132, 127, 127, 127, 127, 123, 132, 131, 127, 127, 126, 128, 127};

void writeMotion(void *arg) {

	if ( motion_buffer[motion_buffer_length - 1] != protocolCheckSum( (uint8_t *) motion_buffer, motion_buffer_length - 1 ) || motion_buffer[MOTION_SIZE_INDEX + 1] > MAXIMUM_POSITIONS ) {

		motion_buffer_length = 0;
		protocolFail();

	} else {

		writeEEPROM( pageAddr( motion_buffer[MOTION_PAGE_INDEX + 1] ) );
		protocolSuccess();

	}

} // writeMotion

// page size loop position1 ... position18
void writeEEPROM(uint16_t addr) {
	
	cli();

	if (motion_buffer_length > 1) {

		// do not write checksum
		motion_buffer_length--;

		for (uint16_t x = MOTION_PAGE_INDEX + 1; x < motion_buffer_length; x++) {

			eeprom_write_byte( (uint8_t *) addr, motion_buffer[x]);
			addr++;

		}

		motion_buffer_length = 0;

	}

	sei();

} // writeEEPROM

// page size loop position1 ... position18
void readEEPROM(uint16_t addr) {

	cli();

	motion_buffer_length = (uint16_t) eeprom_read_byte( (uint8_t *) (addr + MOTION_SIZE_INDEX) );
	motion_buffer_length = motion_buffer_length * POSITION_SIZE + MOTION_DATA_SIZE;

	if (motion_buffer_length < MOTION_BUFFER_SIZE) {

		for (uint16_t x = 0; x < motion_buffer_length; x++) {
		
			motion_buffer[x] = eeprom_read_byte( (uint8_t *) addr);
			addr++;

		}

	} else {

		motion_buffer_length = 0;

	}

	sei();

} // readEEPROM

void playMotion(void *arg) {

	downSemaphore(&usart1_lock);
	uint8_t page = *( (uint8_t *) arg );
	uint8_t interpolation = *( (uint8_t *) (arg+1) );
	uint8_t count = *( (uint8_t *) (arg+2) );
	upSemaphore(&usart1_lock);

	downSemaphore( (Semaphore *) &robot_state.lock );

	if (page != motion_buffer_page) {

		motion_buffer_page = page;
		readEEPROM( pageAddr(page) );

	}

	if ( motion_buffer_length > 1 && page == motion_buffer[MOTION_PAGE_INDEX] ) {

		motion_stop = 0;

		// test
		uint8_t *position = (uint8_t *) home_position;
		if (page < 12) {
			home_position[0] = 6;
			linear(position, POSITION_SIZE);
		}

		for (uint8_t i = 0; i < count && !motion_stop; i++) {

			for (uint8_t j = 0; j < motion_buffer[MOTION_SIZE_INDEX]; j++) {

				//uint8_t *position = (uint8_t *) &motion_buffer[j * POSITION_SIZE + MOTION_DATA_SIZE];

				position = (uint8_t *) &motion_buffer[j * POSITION_SIZE + MOTION_DATA_SIZE];
				
				switch (interpolation) {

					case CMD_LINEAR:
						linear(position, POSITION_SIZE);
						break;

					case CMD_SINUSOIDAL:
						sinusoidal(position, POSITION_SIZE);
						break;

					default:
						break;

				}

			}

		}

		// test
		if (page == 2 || page == 3) {

			position = (uint8_t *) home_position;
			home_position[0] = 1;
			linear(position, POSITION_SIZE);

			uint16_t start_time = ticks3;

			while ( (robot_state.update_vector[0] != 0 || robot_state.update_vector[1] != 0) && (ticks3 - start_time) < 30 /*|| robot_state.update_vector[2] != 0*/ ) {

				position = (uint8_t *) home_position;
				linear(position, POSITION_SIZE);

			}

		}

		protocolSuccess();

	} else {

		protocolFail();

	}

	upSemaphore( (Semaphore *) &robot_state.lock );

} // playMotion

void stopMotion(void *arg) {

	if ( !tryDownSemaphore( (Semaphore *) &robot_state.lock ) )
		motion_stop = 1;
	else
		protocolSuccess();

} // stopMotion
