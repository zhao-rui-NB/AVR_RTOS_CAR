#ifndef __MOTION_H__
#define __MOTION_H__

#include <stdint.h>

#define MOTION_BUFFER_SIZE 256

// 4096 / (MAXIMUM_POSITIONS * POSITION_SIZE + MOTION_DATA_SIZE) = maximum number of motions in eeprom
#define MOTION_DATA_SIZE 2
#define MOTION_PAGE_INDEX 0
#define MOTION_SIZE_INDEX 1

#define MAXIMUM_POSITIONS 10
#define POSITION_SIZE 19

extern volatile uint8_t motion_buffer[];
extern volatile uint16_t motion_buffer_length;
extern volatile uint8_t motion_buffer_page;
extern volatile uint8_t motion_stop;

static inline uint16_t pageAddr(uint8_t page) { return ( (uint16_t) (page - 1) ) * MAXIMUM_POSITIONS * POSITION_SIZE + ( MOTION_DATA_SIZE * (page - 1) ); };  
void writeEEPROM(uint16_t addr);
void readEEPROM(uint16_t addr);

void writeMotion(void *arg);
void playMotion(void *arg);
void stopMotion(void *arg);

#endif
