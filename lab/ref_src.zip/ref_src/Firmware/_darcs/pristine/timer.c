#include "timer.h"
#include "kernel.h"
#include "led.h"

#include <avr/interrupt.h>
#include <avr/io.h>

volatile uint16_t ticks1;
volatile uint16_t ticks3;

void initTimer1(void) {

	TCCR1A = 0;
	// 16MHz/256
	//TCCR1B = (1 << CS12);
	// 16MHz/64
	TCCR1B = (1 << CS11) | (1 << CS10);
	TIFR |= (1 << TOV1);
	// enable Timer1 overflow interrupt
	TIMSK |= (1 << TOIE1);

} // initTimer1

void initTimer3(void) {

        TCCR3A = 0;
        // 16MHz/256
	TCCR3B = (1 << CS32);
	TCCR3C = 0;
	ETIFR |= (1 << TOV3);
	// enable Timer3 overflow interrupt
	ETIMSK |= (1 << TOIE3);

} // initTimer3

ISR(TIMER1_OVF_vect) {

	/*// 1 shot 10ms
	// 16MHz / 256 * 1/100 = 625
	// 2^16 - 625 = 64911
	TCNT1 = 64911;*/

	// 1 shot 1ms
	// 16MHz / 64 * 1/1000 = 250
	// 2^16 - 250 = 65286
	TCNT1 = 65286;

	ticks1++;

	// save state
	// general and special purpose registers
	asm volatile(	"push r2\n\t"
			"push r3\n\t"
			"push r4\n\t"
			"push r5\n\t"
			"push r6\n\t"
			"push r7\n\t"
			"push r8\n\t"
			"push r9\n\t"
			"push r10\n\t"
			"push r11\n\t"
			"push r12\n\t"
			"push r13\n\t"
			"push r14\n\t"
			"push r15\n\t"
			"push r28\n\t"
			"push r29\n\t"
			"in __tmp_reg__,0x3b\n\t"
			"push __tmp_reg__\n\t"	// RAMPZ
			:
			:
		);

	task[current_task].stackPtr = (void *) SP;

	// schedule
	schedule();

	// restore state	
	SP = (uint16_t) task[current_task].stackPtr;

	// general and special purpose registers
	asm volatile(	"pop __tmp_reg__\n\t"
			"out 0x3b,__tmp_reg__\n\t"	// RAMPZ
			"pop r29\n\t"
			"pop r28\n\t"
			"pop r15\n\t"
			"pop r14\n\t"
			"pop r13\n\t"
			"pop r12\n\t"
			"pop r11\n\t"
			"pop r10\n\t"
			"pop r9\n\t"
			"pop r8\n\t"
			"pop r7\n\t"
			"pop r6\n\t"
			"pop r5\n\t"
			"pop r4\n\t"
			"pop r3\n\t"
			"pop r2\n\t"
			:
			:
		);

}

ISR(TIMER3_OVF_vect) {

	// 1 shot 1/10s
	// 16MHz / 256 * 1/10 = 6250
	// 2^16 - 6250 = 59286
	TCNT3 = 59286;
	
	ticks3++;

	rxdLEDOff();
	txdLEDOff();
	manageLEDOff();

}
