#include "adc.h"
#include "kernel.h"
#include "led.h"
#include "serial.h"
#include "timer.h"

#include <avr/io.h>
#include <avr/interrupt.h>

volatile uint8_t battery[3];
volatile uint8_t accelerometer[3];

void initADC(void) {

	// input
	//DDRF &= ~(1 << DDF3);
	// enable pull up
	//PORTF |= (1 << PF3);
	
	//DDRF &= ~(1 << DDF2);
	//PORTF |= (1 << PF2);
	DDRF &= ~(1 << DDF1);
	PORTF |= (1 << PF1);
	//DDRF &= ~(1 << DDF0);
	//PORTF |= (1 << PF0);
	
	// ADC enable
	// ADC start conversion
	// ADC free running mode
	// set prescalar 128
	ADCSRA = (1 << ADEN) | (1 << ADSC) | (1 << ADFR) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);

	// ADC3
	//ADMUX = (1 << MUX1) | (1 << MUX0);
	//ADMUX = (1 << MUX1);
	ADMUX = (1 << MUX0);
	//ADMUX = 0;

} // initADC

void initUpButton(void) {

	DDRE &= ~(1 << DDE4);
	PORTE |= (1 << PE4);

	EIFR |= (1 << INTF4);
	EIMSK |= (1 << INT4);

} // initUpButton

void chargeBattery(void *arg) {

	int16_t adc_value;
	uint16_t start_time = ticks3;

	DDRB |= (1 << DDB5);
	PORTB |= (1 << PB5);

	initADC();

	while(1) {

		PORTB ^= (1 << PB5);

		adc_value = ADC;
		battery[0] = 1;
		battery[1] = (uint8_t) (adc_value >> 8);
		battery[2] = (uint8_t) adc_value;
		
		if ( (ticks3 - start_time) > 5 ) {

			manageLEDOn();

			downSemaphore(&usart1_lock);
			transmitBufferUSART1( (uint8_t *) battery, 3 );
			upSemaphore(&usart1_lock);
	
			start_time = ticks3;

		}

	}

} // chargeBattery

void readAccelerometer(void *arg) {

	/*static uint8_t channel = 0;

	initAccelerometer();

	while (1) {

		while( !ADCSRA & (1 << ADIF) )
			asm volatile("nop"::);

		ADMUX =  (1 << channel);
		accelerometer[channel] = ADC;

		if (++channel > 2)
			channel = 0;

	}*/

} // readAccelerometer

void transmitTest(void *arg) {

	char letter = 'a';

	while(1) {

		for (uint8_t x = 0; x < 26; x++) {

			downSemaphore(&usart1_lock);
			transmitBufferUSART1( (uint8_t *) &letter, 1);
			upSemaphore(&usart1_lock);
			letter++;
		}

		letter = 'a';

	}

} // transmitTest

ISR(INT4_vect) {

	static uint8_t charging = 0;

	if (!charging) {

		//startTask( (void *) &transmitTest, 0, MAXIMUM_PRIORITY, MINIMUM_STACK_SIZE );
		startTask( (void *) &chargeBattery, 0, MEDIUM_PRIORITY, MINIMUM_STACK_SIZE );
		charging = 1;

	}

}
