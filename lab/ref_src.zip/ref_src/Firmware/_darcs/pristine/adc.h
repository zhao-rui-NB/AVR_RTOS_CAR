#ifndef __ADC_H__
#define __ADC_H__

#include <stdint.h>

extern volatile uint8_t battery[];
extern volatile uint8_t accelerometer[];

void initADC(void);
void initUpButton(void);
void chargeBattery(void *arg);
void readAccelerometer(void *arg);

#endif
