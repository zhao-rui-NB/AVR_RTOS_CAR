#ifndef __INTERPOLATION_H__
#define __INTERPOLATION_H__

#include <stdint.h>

void interpolate(void *arg);
void linear(uint8_t buffer[], uint8_t buffer_length);
void sinusoidal(uint8_t buffer[], uint8_t buffer_length);

#endif
