#include "interpolation.h"
#include "ax12motor.h"
#include "fixed_point.h"
#include "protocol.h"
#include "serial.h"
#include "state.h"
#include "timer.h"

#include <avr/pgmspace.h>

// cosine lookup table fixed point
const int8_t COSINE[] /*PROGMEM*/ = { 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 31, 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29, 29, 29, 29, 29, 28, 28, 28, 27, 27, 27, 27, 26, 26, 26, 25, 25, 25, 24, 24, 23, 23, 23, 22, 22, 21, 21, 21, 20, 20, 19, 19, 18, 18, 17, 17, 16, 16, 16, 15, 15, 14, 14, 13, 13, 12, 11, 11, 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 5, 4, 4, 3, 3, 2, 2, 1, 1, 0, -1, -1, -2, -2, -3, -3, -4, -4, -5, -6, -6, -7, -7, -8, -8, -9, -9, -10, -10, -11, -11, -12, -13, -13, -14, -14, -15, -15, -16, -16, -16, -17, -17, -18, -18, -19, -19, -20, -20, -21, -21, -21, -22, -22, -23, -23, -23, -24, -24, -25, -25, -25, -26, -26, -26, -27, -27, -27, -27, -28, -28, -28, -29, -29, -29, -29, -29, -30, -30, -30, -30, -30, -31, -31, -31, -31, -31, -31, -31, -32, -32, -32, -32, -32, -32, -32, -32, -32, -32 };

void interpolate(void *arg) {

	downSemaphore(&usart1_lock);

	// copy usart1 rx buffer
	uint8_t buffer_length = *( (uint8_t *) arg ) - 1;
	uint8_t buffer[buffer_length];
	
	uint8_t x;
	for (x = 0; x < buffer_length; x++)
		buffer[x] = usart1_rx_buffer[x];

	uint8_t checksum = usart1_rx_buffer[x];

	upSemaphore(&usart1_lock);

	if ( checksum == protocolCheckSum(buffer, buffer_length) ) {

		switch(buffer[0]) {

			case CMD_LINEAR:
				downSemaphore( (Semaphore *) &robot_state.lock );
				linear(&buffer[1], buffer_length - 1);
				upSemaphore( (Semaphore *) &robot_state.lock );
				break;

			case CMD_SINUSOIDAL:
				downSemaphore( (Semaphore *) &robot_state.lock );
				sinusoidal(&buffer[1], buffer_length - 1); 
				upSemaphore( (Semaphore *) &robot_state.lock );
				break;

			default:
				break;

		}

		protocolSuccess();

	} else {

		protocolFail();

	}

} // interpolate

void linear(uint8_t buffer[], uint8_t buffer_length) {

	uint8_t duration = *(buffer++);
	int16_t m[NUMBER_OF_SERVOS];
	uint16_t speed = (duration > 1 ? AX12MOTOR_MIN_SPEED : AX12MOTOR_MAX_SPEED);

	for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++) {

		m[x] = fpDiv( fpInt(buffer[x] - robot_state.position[x]), fpInt(duration) ); 

		uint16_t temp_speed;
		if (m[x] < 0)
                        temp_speed = ( (uint16_t) fpRealI( fpMul( m[x], fpInt(-20) ) ) ) & AX12MOTOR_MAX_SPEED;
                else
                        temp_speed = ( (uint16_t) fpRealI( fpMul( m[x], fpInt(20) ) ) ) & AX12MOTOR_MAX_SPEED;

                if (temp_speed > speed)
                        speed = temp_speed;

		/*uint16_t temp_speed;
		if (m[x] < 0)
			temp_speed = (uint16_t) fpRealI( fpMul( fpDiv( m[x], fpInt(256) ), fpInt(-AX12MOTOR_MAX_SPEED) ) );
		else
			temp_speed = (uint16_t) fpRealI( fpMul( fpDiv( m[x], fpInt(256) ), fpInt(AX12MOTOR_MAX_SPEED) ) );

		if (temp_speed > speed)
			speed = temp_speed;*/

	}

	uint16_t start_time = ticks3;
	uint8_t time = 1;
	uint8_t new_position[NUMBER_OF_SERVOS];

	while(time <= duration) {

		for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++)
			new_position[x] = (uint8_t) fpRealI( fpAdd( fpMul( m[x], fpInt(time) ), fpInt(robot_state.position[x]) ) );
		
		syncSetPositionAndSpeed(new_position, speed);

		time = ticks3 - start_time;

	}

	syncSetPositionAndSpeed(buffer, speed);

	for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++)
		robot_state.position[x] = buffer[x];

} // linear

void sinusoidal(uint8_t buffer[], uint8_t buffer_length) {

	uint8_t duration = *(buffer++);
	uint8_t duration2 = duration / 2;
	int16_t theta_d[NUMBER_OF_SERVOS];
	uint16_t speed = AX12MOTOR_MIN_SPEED;

	for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++)
		theta_d[x] = fpDiv( fpInt(buffer[x] - robot_state.position[x]), fpInt(duration) );

	uint16_t start_time = ticks3;
	uint8_t time = 1;
	uint8_t new_position[NUMBER_OF_SERVOS];

	while(time <= duration2) {

		for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++) {

			uint16_t index = (uint16_t) fpRealI( fpMul( fpMul( FP_2_PI, fpDiv( fpInt(time), fpInt(duration) ) ), FP_RAD_TO_DEG ) );
			int16_t cos_lookup = (int16_t) COSINE[index]; //pgm_read_byte( COSINE[index] );
			int16_t m = fpMul( theta_d[x], fpSub(FP_1, cos_lookup) );

			new_position[x] = (uint8_t) fpRealI( fpAdd( fpMul( m, fpInt(time) ), fpInt(robot_state.position[x] ) ) );

                	uint16_t temp_speed;
                	if (m < 0)
                        	temp_speed = ( (uint16_t) fpRealI( fpMul( m, fpInt(-20) ) ) ) & AX12MOTOR_MAX_SPEED;
                	else
                        	temp_speed = ( (uint16_t) fpRealI( fpMul( m, fpInt(20) ) ) ) & AX12MOTOR_MAX_SPEED;

                	if (temp_speed > speed)
                        	speed = temp_speed;

		}

		syncSetPositionAndSpeed(new_position, speed);

		time = ticks3 - start_time;

	}

	syncSetPositionAndSpeed(buffer, speed);

	for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++)
		robot_state.position[x] = buffer[x];

} // sinusoidal
