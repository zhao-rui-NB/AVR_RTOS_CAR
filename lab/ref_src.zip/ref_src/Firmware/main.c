#include "adc.h"
#include "kernel.h"
#include "led.h"
#include "serial.h"
#include "state.h"
#include "timer.h"

#include <avr/interrupt.h>

int main(void) {

	initKernel();
	initLEDs();
	//initState();
	initTimer1();
	initTimer3();
	initRS485();
	initUpButton();
	initUSART0();
	initUSART1();

	playLEDOn();

	startTask( (void *) &initState, 0, MINIMUM_PRIORITY, MINIMUM_STACK_SIZE );

	// enable interrupts
	sei();

	return 0;

} // main
