#include "serial.h"
#include "adc.h"
#include "ax12motor.h"
#include "interpolation.h"
#include "led.h"
#include "motion.h"
#include "protocol.h"
#include "state.h"

#include <avr/interrupt.h>

volatile uint8_t usart0_rx_buffer[USART0_RX_BUFFER_SIZE];
volatile uint8_t usart0_rx_buffer_length;
Semaphore usart0_lock;
volatile uint8_t usart1_rx_buffer[USART1_RX_BUFFER_SIZE];
volatile uint8_t usart1_rx_buffer_length;
Semaphore usart1_lock;

void initRS485(void) {

	// set data direction output
	// RS485 half duplex
	DDRE |= (1 << DDE3) | (1 << DDE2);

} // initRS485

void initUSART0(void) {

	// double usart transmission speed
	UCSR0A = (1 << U2X0);

	// rx complete interrupt
	// receiver
	// transmitter
	UCSR0B = (1 << RXCIE0) | (1 << RXEN0) | (1 << TXEN0);

	// 8N1
	// asynchronous
	// parity disabled
	// 1 stop bit
	// character size 8 bit
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);

	// baud rate
	UBRR0H = (uint8_t) (USART0_BAUD_RATE >> 8);
	UBRR0L = (uint8_t) USART0_BAUD_RATE;

	RS485_RX;

	initSemaphore(&usart0_lock, 1);

} // initUSART0

void initUSART1(void) {

	// double usart transmission speed
	UCSR1A = (1 << U2X1);

	// rx complete interrupt
	// receiver
	// transmitter
	UCSR1B = (1 << RXCIE1) | (1 << RXEN1) | (1 << TXEN1);

	// 8N1
	// asynchronous
	// parity disabled
	// 1 stop bit
	// character size 8 bit
	UCSR1C = (1 << UCSZ11) | (1 << UCSZ10);

	// baud rate
	UBRR1H = (uint8_t) (USART1_BAUD_RATE >> 8);
	UBRR1L = (uint8_t) USART1_BAUD_RATE;

	reply_status = REPLY_ON;

	initSemaphore(&usart1_lock, 1);

} // initUSART1

// atomic
void transmitBufferUSART0(uint8_t const buffer[], uint8_t buffer_length) {

	cli();

	RS485_TX;

	for (uint8_t x = 0; x < buffer_length; x++) {

		UCSR0A |= (1 << TXC0);

		while ( !( UCSR0A & (1 << UDRE0) ) )
			asm volatile("nop"::);

		UDR0 = buffer[x];

	}

	while ( !( UCSR0A & (1 << TXC0) ) )
		asm volatile("nop"::);

	RS485_RX;

	sei();

} // transmitBufferUSART0

void transmitBufferUSART1(uint8_t const buffer[], uint8_t buffer_length) {

	for (uint8_t x = 0; x < buffer_length; x++) {

		while ( !( UCSR1A & (1 << UDRE1) ) )
			asm volatile("nop"::);

		UDR1 = buffer[x];

		txdLEDOn();

	}

        while ( !( UCSR1A & (1 << TXC1) ) )
                asm volatile("nop"::);

} // transmitBufferUSART1

void transmitStringUSART1(char *msg) {

        for (uint8_t x = 0; msg[x] != '\0'; x++) {

                while ( !( UCSR1A & (1 << UDRE1) ) )
                        asm volatile("nop"::);

		UDR1 = msg[x];

		txdLEDOn();

        }

        while ( !( UCSR1A & (1 << TXC1) ) )
                asm volatile("nop"::);

} // transmitStringUSART1

// 0xff 0xff id length error parameter1 parameter2 ... parameterN checksum
ISR(USART0_RX_vect) {

	static int8_t x = -2;
	static uint8_t length = 0;

	uint8_t data = UDR0;

	if (x < 0 && data == AX12MOTOR_HEADER0) {

		x++;

	} else if (x < 0 && data != AX12MOTOR_HEADER0) { 
	
		x = -2;

	} else {

		if (x == 1)
			length = data + x;
		
		// ensure no threads are reading usart0 rx buffer
		if ( tryDownSemaphore(&usart0_lock) ) {
			
			usart0_rx_buffer[x++] = data;
			usart0_rx_buffer_length = x;

		} else {

			x = -2;

		}

		if (length > 0)
			length--;

		if (x > 1 && length == 0) {

			if (reply_status == REPLY_ON)
				startTask( (void *) &handleReply, (void *) &usart0_rx_buffer_length, MEDIUM_PRIORITY, MINIMUM_STACK_SIZE );
			
			x = -2;

		}

	}

}

ISR(USART1_RX_vect) {

	static int8_t x = -1;

	uint8_t data = UDR1;

	rxdLEDOn();

	if (data == CMD_HEADER) {

		x = 0;

	} else if (x >= 0) {

		// ensure no threads are reading usart1 rx buffer
		if ( tryDownSemaphore(&usart1_lock) )
			usart1_rx_buffer[x++] = data;
		else
			x = -1;

	}

	if (x > 0) {

		switch ( usart1_rx_buffer[0] ) {

			case CMD_LINEAR:
			case CMD_SINUSOIDAL:
				
				if (x == CMD_INTERPOLATE_LENGTH) {

					usart1_rx_buffer_length = x;
					startTask( (void *) &interpolate, (void *) &usart1_rx_buffer_length, MAXIMUM_PRIORITY, MAXIMUM_STACK_SIZE );
					x = -1;

				}
					
				break;

			case CMD_GET_POSITION:
			case CMD_MOTOR_OFF:
			case CMD_MOTOR_ON:
			case CMD_PING:

				if (x == CMD_DEFAULT_LENGTH) { 

					usart1_rx_buffer_length = x;
					startTask( (void *) &handleCommand, (void *) &usart1_rx_buffer_length, MEDIUM_PRIORITY, MINIMUM_STACK_SIZE );
					x = -1;

				}		

				break;

			case CMD_SET_POSITION_AND_SPEED:

				if (x == CMD_SET_POSITION_AND_SPEED_LENGTH) {

					usart1_rx_buffer_length = x;
					startTask( (void *) &handleCommand, (void *) &usart1_rx_buffer_length, MEDIUM_PRIORITY, MINIMUM_STACK_SIZE );
					x = -1;

				}

				break;

			case CMD_WRITE_MOTION:
				
				if (x == 1) {

					motion_buffer_length = 0;
					motion_buffer[motion_buffer_length++] = usart1_rx_buffer[0];

				} else {

					motion_buffer[motion_buffer_length++] = usart1_rx_buffer[x - 1];
					x = 1;

					if (motion_buffer_length == MOTION_BUFFER_SIZE) {

						x = -1;

					} else if ( motion_buffer_length == (motion_buffer[MOTION_SIZE_INDEX + 1] * POSITION_SIZE + 4) ) {

						startTask( (void *) &writeMotion, 0, MEDIUM_PRIORITY, MEDIUM_STACK_SIZE );
						x = -1;

					}

				}

				break;

			case CMD_PLAY_MOTION:

				if (x == CMD_PLAY_LENGTH) {

					if ( usart1_rx_buffer[ CMD_PLAY_LENGTH - 1 ] == protocolCheckSum( (uint8_t *) usart1_rx_buffer, CMD_PLAY_LENGTH - 1 ) )

						startTask( (void *) &playMotion, (void *) &usart1_rx_buffer[1], MAXIMUM_PRIORITY, MEDIUM_STACK_SIZE);

					x = -1;

				}

				break;

			case CMD_STOP_MOTION:

				if (x == CMD_STOP_LENGTH) { 

					usart1_rx_buffer_length = x;
					startTask( (void *) &stopMotion, (void *) &usart1_rx_buffer_length, MAXIMUM_PRIORITY, MINIMUM_STACK_SIZE );
					x = -1;

				}		

				break;

			case CMD_ACCELEROMETER:
				
				/*if (x == CMD_ACCELEROMETER_LENGTH) {

					if ( usart1_rx_buffer[1] == protocolCheckSum( (uint8_t *) usart1_rx_buffer, 1 ) )
						transmitBufferUSART1( (uint8_t *) accelerometer, 3);

					x = -1;

				}*/

				if (x == CMD_ACCELEROMETER_LENGTH) {

					if ( usart1_rx_buffer[ CMD_ACCELEROMETER_LENGTH - 1 ] == protocolCheckSum( (uint8_t *) usart1_rx_buffer, CMD_ACCELEROMETER_LENGTH - 1 ) ) {

						robot_state.update_vector[0] = (int8_t) usart1_rx_buffer[1];
						robot_state.update_vector[1] = (int8_t) usart1_rx_buffer[2];	
						robot_state.update_vector[2] = (int8_t) usart1_rx_buffer[3];	
					
					}
					
					x = -1;

				}

				break;

			case CMD_BALANCE:

                                if (x == CMD_DEFAULT_LENGTH) {

                                        if ( usart1_rx_buffer[2] == protocolCheckSum( (uint8_t *) usart1_rx_buffer, 2 ) )
                                                //setBalanceStatus(usart1_rx_buffer[1]);

                                        x = -1;

                                }

                                break;

			case CMD_RESET:

				if (x == CMD_RESET_LENGTH) {

					if ( usart1_rx_buffer[ CMD_RESET_LENGTH - 1 ] == protocolCheckSum( (uint8_t *) usart1_rx_buffer, CMD_RESET_LENGTH - 1 ) )

						startTask( (void *) &reset, (void *) &usart1_rx_buffer[1], MAXIMUM_PRIORITY, MINIMUM_STACK_SIZE);

					x = -1;

				}

				break;

			case CMD_MOVE_LOAD_CHECK:

				if (x == CMD_MOVE_LOAD_CHECK_LENGTH) {

					usart1_rx_buffer_length = x;
					startTask( (void *) &handleCommand, (void *) &usart1_rx_buffer_length, MEDIUM_PRIORITY, MINIMUM_STACK_SIZE );
					x = -1;

				}

				break;

			case CMD_COMPENSATION:

				if (x == CMD_COMPENSATION_LENGTH) {

					if ( usart1_rx_buffer[ CMD_COMPENSATION_LENGTH - 1 ] == protocolCheckSum( (uint8_t *) usart1_rx_buffer, CMD_COMPENSATION_LENGTH - 1 ) ) {

						for (uint8_t i = 0; i < NUMBER_OF_SERVOS; i++)
							robot_state.compensation_matrix[i] = (int8_t) (usart1_rx_buffer[i + 1] - 1);


					}

					x = -1;


				}

				break;

			default:
				x = -1;
				protocolFail();

				break;

		}

	}

}
