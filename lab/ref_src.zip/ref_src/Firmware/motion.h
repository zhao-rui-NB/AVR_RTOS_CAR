#ifndef __MOTION_H__
#define __MOTION_H__

#include <stdint.h>

#define MOTION_BUFFER_SIZE 256

// 4096 / (MAXIMUM_POSITIONS * POSITION_SIZE + MOTION_DATA_SIZE) = maximum number of motions in eeprom
#define MOTION_DATA_SIZE 2
#define MOTION_PAGE_INDEX 0
#define MOTION_SIZE_INDEX 1

#define MAXIMUM_POSITIONS 10
#define POSITION_SIZE 19

extern volatile uint8_t motion_buffer[];
extern volatile uint16_t motion_buffer_length;
extern volatile uint8_t motion_buffer_page;
extern volatile uint8_t motion_stop;

static inline uint16_t pageAddr(uint8_t page) { return ( (uint16_t) (page - 1) ) * MAXIMUM_POSITIONS * POSITION_SIZE + ( MOTION_DATA_SIZE * (page - 1) ); };  
void writeEEPROM(uint16_t addr);
void readEEPROM(uint16_t addr);

void writeMotion(void *arg);
void playMotion(void *arg);
void stopMotion(void *arg);

enum Joints {

        LEFT_SHOULDER_LATERAL = 2,
        LEFT_SHOULDER_LATERAL_INDEX = 1,
        LEFT_SHOULDER_FRONTAL = 4,
        LEFT_SHOULDER_FRONTAL_INDEX = 3,
        LEFT_ELBOW_FRONTAL = 6,
        LEFT_ELBOW_FRONTAL_INDEX = 5,
        RIGHT_SHOULDER_LATERAL = 1,
        RIGHT_SHOULDER_LATERAL_INDEX = 0,
        RIGHT_SHOULDER_FRONTAL = 3,
        RIGHT_SHOULDER_FRONTAL_INDEX = 2,
        RIGHT_ELBOW_FRONTAL = 5,
        RIGHT_ELBOW_FRONTAL_INDEX = 4,
        LEFT_TORSO_TRAVERSE = 8,
        LEFT_TORSO_TRAVERSE_INDEX = 7,
        RIGHT_TORSO_TRAVERSE = 7,
        RIGHT_TORSO_TRAVERSE_INDEX = 6,
        LEFT_HIP_LATERAL = 12,
        LEFT_HIP_LATERAL_INDEX = 11,
        LEFT_HIP_FRONTAL = 10,
        LEFT_HIP_FRONTAL_INDEX = 9,
        LEFT_KNEE_LATERAL = 14,
        LEFT_KNEE_LATERAL_INDEX = 13,
        LEFT_ANKLE_LATERAL = 16,
        LEFT_ANKLE_LATERAL_INDEX = 15,
        LEFT_ANKLE_FRONTAL = 18,
        LEFT_ANKLE_FRONTAL_INDEX = 17,
        RIGHT_HIP_LATERAL = 11,
        RIGHT_HIP_LATERAL_INDEX = 10,
        RIGHT_HIP_FRONTAL = 9,
        RIGHT_HIP_FRONTAL_INDEX = 8,
        RIGHT_KNEE_LATERAL = 13,
        RIGHT_KNEE_LATERAL_INDEX = 12,
        RIGHT_ANKLE_LATERAL = 15,
        RIGHT_ANKLE_LATERAL_INDEX = 14,
        RIGHT_ANKLE_FRONTAL = 17,
        RIGHT_ANKLE_FRONTAL_INDEX = 16

};

#endif
