#include "ax12motor.h"
#include "kernel.h"
#include "protocol.h"
#include "serial.h"
#include "state.h"
#include "timer.h"

void handleCommand(void *arg) {

	downSemaphore(&usart1_lock);

	// copy usart1 rx buffer
	uint8_t buffer_length = *( (uint8_t *) arg ) - 1;
	uint8_t buffer[buffer_length];
	
	uint8_t x;
	for (x = 0; x < buffer_length; x++)
		buffer[x] = usart1_rx_buffer[x];

	uint8_t checksum = usart1_rx_buffer[x];

	upSemaphore(&usart1_lock);

	if ( checksum == protocolCheckSum(buffer, buffer_length) ) {

		switch(buffer[0]) {

			case CMD_GET_POSITION:
				getPosition(buffer[1], REPLY_ON);
				break;

			case CMD_SET_POSITION_AND_SPEED:
				setPositionAndSpeed(buffer[1], buffer[2], buffer[3], REPLY_ON);
				break;

			case CMD_MOTOR_OFF:
				motorOff(buffer[1], REPLY_ON);
				break;

			case CMD_MOTOR_ON:
				motorOn(buffer[1], REPLY_ON);
				break;

			case CMD_PING:
				ping(buffer[1], REPLY_ON);
				break;

			case CMD_MOVE_LOAD_CHECK:
				moveLoadCheck(buffer[1], buffer[2], REPLY_ON);

			default:
				break;

		}

	} else {

		protocolFail();

	}

} // handleCommand

// id length error parameter1 parameter2 ... parameterN checksum
void handleReply(void *arg) {

	downSemaphore(&usart0_lock);

	// copy usart0 rx buffer
	uint8_t buffer_length = *( (uint8_t *) arg ) - 1;
	uint8_t buffer[buffer_length];
	
	uint8_t x;
	for (x = 0; x < buffer_length; x++)
		buffer[x] = usart0_rx_buffer[x];

	uint8_t checksum = usart0_rx_buffer[x];

	upSemaphore(&usart0_lock);

	uint8_t n = 0;
	uint8_t *parameters = 0;

	if (buffer[1] > 2) {
		
		n = buffer[1] - 2;
		parameters = &buffer[3];

	}

	if ( checksum == calculateCheckSum(buffer[0], 0, parameters, n) ) {

		uint8_t reply_length = buffer[1] + 3;
		uint8_t reply[reply_length];
		reply[0] = 0xff;
		reply[1] = buffer[0]; // id
		reply[2] = buffer[1]; // length
		reply[3] = buffer[2]; // error

		for (uint8_t x = 0; x < n; x++)
			reply[x + 4] = buffer[x + 3]; // parameters

		reply[reply_length - 1] = protocolCheckSum(&reply[1], reply_length - 2); // checksum	
		downSemaphore(&usart1_lock);
		transmitBufferUSART1(reply, reply_length);
		upSemaphore(&usart1_lock);

	} else {

		protocolFail();

        }

} // handleReply

// Check Sum = ~ (ID + Length + Instruction + Parameter1 + ... Parameter N)
// If the calculated value is larger than 255, the lower byte is defined as the checksum
// length = n + 2
uint8_t calculateCheckSum(uint8_t id, uint8_t instruction, uint8_t const parameters[], uint8_t n) {

        uint16_t result = id + (n + 2) + instruction;

        for (uint8_t x = 0; x < n; x++)
                result += parameters[x];

        return (uint8_t) (~result);

} // calculateCheckSum

uint8_t getPosition(uint8_t id, uint8_t replyStatus) {

	setReplyStatus(replyStatus);

	uint8_t result = 0;

	uint8_t buffer[8];

	// 0xff 0xff id length instruction address length checksum
	buffer[0] = AX12MOTOR_HEADER0;
	buffer[1] = AX12MOTOR_HEADER1;
	buffer[2] = id;
	buffer[3] = 0x04;
	buffer[4] = AX12MOTOR_READ_DATA;
	buffer[5] = AX12MOTOR_PRESENT_POSITION_L;
	buffer[6] = 0x02;
	buffer[7] = calculateCheckSum(id, AX12MOTOR_READ_DATA, &buffer[5], 0x02);

	downSemaphore(&usart0_lock);
	transmitBufferUSART0(buffer, 8);
	upSemaphore(&usart0_lock);

	uint16_t start_time = ticks1;
	while( usart0_rx_buffer_length < 6 || (ticks1 - start_time) < AX12MOTOR_REPLY_TIMEOUT )
		asm volatile("nop"::);

	uint8_t reply[6];

	downSemaphore(&usart0_lock);
		
		if (usart0_rx_buffer_length == 6) {
			
			for (uint8_t x = 0; x < 6; x++)
				reply[x] = usart0_rx_buffer[x];

		}
	
	upSemaphore(&usart0_lock);

	if ( reply[0] == id && reply[1] == 4 && reply[2] == 0 && reply[5] == calculateCheckSum(reply[0], 0, &reply[3], 2) ) {

		uint16_t position = ( (reply[4] << 8) | reply[3] ) / 4;
	
		if (position > 0xfe)
			position &= 0xfe;

		result =  (uint8_t) position;

	} 

	setReplyStatus(REPLY_ON);

	return result;

} // getPosition

uint16_t getLoad(uint8_t id, uint8_t replyStatus) {

	setReplyStatus(replyStatus);

	uint16_t result = 0;

	uint8_t buffer[8];

	// 0xff 0xff id length instruction address length checksum
	buffer[0] = AX12MOTOR_HEADER0;
	buffer[1] = AX12MOTOR_HEADER1;
	buffer[2] = id;
	buffer[3] = 0x04;
	buffer[4] = AX12MOTOR_READ_DATA;
	buffer[5] = AX12MOTOR_PRESENT_LOAD_L;
	buffer[6] = 0x02;
	buffer[7] = calculateCheckSum(id, AX12MOTOR_READ_DATA, &buffer[5], 0x02);
	
	downSemaphore(&usart0_lock);
	transmitBufferUSART0(buffer, 8);
	upSemaphore(&usart0_lock);

	uint16_t start_time = ticks1;
	while( usart0_rx_buffer_length < 6 || (ticks1 - start_time) < AX12MOTOR_REPLY_TIMEOUT )
		asm volatile("nop"::);

	uint8_t reply[6];

	downSemaphore(&usart0_lock);
		
		if (usart0_rx_buffer_length == 6) {
			
			for (uint8_t x = 0; x < 6; x++)
				reply[x] = usart0_rx_buffer[x];

		}
	
	upSemaphore(&usart0_lock);

	if ( reply[0] == id && reply[1] == 4 && reply[2] == 0 && reply[5] == calculateCheckSum(reply[0], 0, &reply[3], 2) ) {

		result = (reply[4] << 8) | reply[3];
	
	}

	setReplyStatus(REPLY_ON);

	return result;

} // getLoad

void motorOff(uint8_t id, uint8_t replyStatus) {

	setReplyStatus(replyStatus);
	
	uint8_t buffer[8];

	// 0xff 0xff id length instruction address data1 checksum
	buffer[0] = AX12MOTOR_HEADER0;
	buffer[1] = AX12MOTOR_HEADER1;
	buffer[2] = id;
	buffer[3] = 0x04;
	buffer[4] = AX12MOTOR_WRITE_DATA;
	buffer[5] = AX12MOTOR_TORQUE_ENABLE;
	buffer[6] = 0x00;
	buffer[7] = calculateCheckSum(id, AX12MOTOR_WRITE_DATA, &buffer[5], 0x02);

	downSemaphore(&usart0_lock);
	transmitBufferUSART0(buffer, 8);
	upSemaphore(&usart0_lock);

        uint16_t start_time = ticks1;
        while( usart0_rx_buffer_length < 4 || (ticks1 - start_time) < AX12MOTOR_REPLY_TIMEOUT )
                asm volatile("nop"::);

	setReplyStatus(REPLY_ON);

} // motorOff

void motorOn(uint8_t id, uint8_t replyStatus) {

	setReplyStatus(replyStatus);

	uint8_t buffer[8];

	// 0xff 0xff id length instruction address data1 checksum
	buffer[0] = AX12MOTOR_HEADER0;
	buffer[1] = AX12MOTOR_HEADER1;
	buffer[2] = id;
	buffer[3] = 0x04;
	buffer[4] = AX12MOTOR_WRITE_DATA;
	buffer[5] = AX12MOTOR_TORQUE_ENABLE;
	buffer[6] = 0x01;
	buffer[7] = calculateCheckSum(id, AX12MOTOR_WRITE_DATA, &buffer[5], 0x02);

	downSemaphore(&usart0_lock);
	transmitBufferUSART0(buffer, 8);
	upSemaphore(&usart0_lock);

        uint16_t start_time = ticks1;
        while( usart0_rx_buffer_length < 4 || (ticks1 - start_time) < AX12MOTOR_REPLY_TIMEOUT )
                asm volatile("nop"::);

	setReplyStatus(REPLY_ON);

} // motorOn

void ping(uint8_t id, uint8_t replyStatus) {

	setReplyStatus(replyStatus);

	uint8_t buffer[6];

	// 0xff 0xff id length instruction checksum
	buffer[0] = AX12MOTOR_HEADER0;
	buffer[1] = AX12MOTOR_HEADER1;
	buffer[2] = id;
	buffer[3] = 0x02;
	buffer[4] = AX12MOTOR_PING;
	buffer[5] = calculateCheckSum(id, AX12MOTOR_PING, 0, 0x00);

	downSemaphore(&usart0_lock);
	transmitBufferUSART0(buffer, 6);
	upSemaphore(&usart0_lock);

        uint16_t start_time = ticks1;
        while( usart0_rx_buffer_length < 4 || (ticks1 - start_time) < AX12MOTOR_REPLY_TIMEOUT )
                asm volatile("nop"::);

	setReplyStatus(REPLY_ON);

} // ping

void setPositionAndSpeed(uint8_t id, uint8_t position, uint8_t speed, uint8_t replyStatus) {

	setReplyStatus(replyStatus);

	uint16_t p = position * 4;
	uint16_t s = speed * 4;

        uint8_t buffer[11];

	// 0xff 0xff id length instruction address data1 data2 data3 data4 checksum
        buffer[0] = AX12MOTOR_HEADER0;
        buffer[1] = AX12MOTOR_HEADER1;
        buffer[2] = id;
        buffer[3] = 0x07;
        buffer[4] = AX12MOTOR_WRITE_DATA;
        buffer[5] = AX12MOTOR_GOAL_POSITION_L;
        buffer[6] = (uint8_t) p;
	buffer[7] = (uint8_t) (p >> 8);
	buffer[8] = (uint8_t) s;
	buffer[9] = (uint8_t) (s >> 8);
        buffer[10] = calculateCheckSum(id, AX12MOTOR_WRITE_DATA, &buffer[5], 0x05);

        downSemaphore(&usart0_lock);
        transmitBufferUSART0(buffer, 11);
        upSemaphore(&usart0_lock);

        uint16_t start_time = ticks1;
        while( usart0_rx_buffer_length < 4 || (ticks1 - start_time) < AX12MOTOR_REPLY_TIMEOUT )
                asm volatile("nop"::);

	// temp
	robot_state.position[id - 1] = position;

	setReplyStatus(REPLY_ON);

} // setPositionAndSpeed

// n = 18 * 5 + 2 = 92
// buffer_size = n + 6 = 98
// length = n + 2 = 96
void syncSetPositionAndSpeed(uint8_t const positions[], uint16_t speed) {

	uint8_t buffer[98];
	
	buffer[0] = AX12MOTOR_HEADER0;
	buffer[1] = AX12MOTOR_HEADER1;
	buffer[2] = AX12MOTOR_BROADCAST_ID;
	buffer[3] = 94; // length
	buffer[4] = AX12MOTOR_SYNC_WRITE;
	buffer[5] = AX12MOTOR_GOAL_POSITION_L;
	buffer[6] = 0x04;

	uint8_t i = 7;

	for (uint8_t x = 0; x < NUMBER_OF_SERVOS; x++) {

		uint16_t position = positions[x] * 4;
		buffer[i++] = x + 1; // id
		buffer[i++] = (uint8_t) position; // position_l
		buffer[i++] = (uint8_t) (position >> 8); // position_h
		buffer[i++] = (uint8_t) speed; // speed_l
		buffer[i++] = (uint8_t) (speed >> 8); // speed_h

	}

	buffer[i] = calculateCheckSum(AX12MOTOR_BROADCAST_ID, AX12MOTOR_SYNC_WRITE, &buffer[5], 92);

	downSemaphore(&usart0_lock);
	transmitBufferUSART0(buffer, 98);
	upSemaphore(&usart0_lock);

} // syncSetPositionAndDuration

void moveLoadCheck(uint8_t id, uint8_t direction, uint8_t replyStatus) {

	setReplyStatus(replyStatus);

	readLoad(id);

	while( robot_state.load[id - 1] < 512 && robot_state.load[id - 1] > -512 ) {

		switch(direction) {

			case DIRECTION_CW:
				setPositionAndSpeed(id, robot_state.position[id - 1] + 2, 64, REPLY_OFF);
				break;
			
			case DIRECTION_CCW:
				setPositionAndSpeed(id, robot_state.position[id - 1] - 2, 64, REPLY_OFF);
				break;

			default:
				break;

		}

		readLoad(id);

	}

	switch(direction) {

		case DIRECTION_CW:
			setPositionAndSpeed(id, robot_state.position[id - 1] - 10, 64, REPLY_OFF);
			break;
		
		case DIRECTION_CCW:
			setPositionAndSpeed(id, robot_state.position[id - 1] + 10, 64, REPLY_OFF);
			break;

		default:
			break;

	}

	if ( getReplyStatus() )
		protocolSuccess();

	setReplyStatus(REPLY_ON);

} // moveLoadCheck

void writeByte(uint8_t id, uint8_t address, uint8_t data, uint8_t replyStatus) {

	setReplyStatus(replyStatus);

	uint8_t buffer[8];

	// 0xff 0xff id length instruction address data checksum
	buffer[0] = AX12MOTOR_HEADER0;
	buffer[1] = AX12MOTOR_HEADER1;
	buffer[2] = id;
	buffer[3] = 0x04;
	buffer[4] = AX12MOTOR_WRITE_DATA;
	buffer[5] = address;
	buffer[6] = data;
	buffer[7] = calculateCheckSum(id, AX12MOTOR_WRITE_DATA, &buffer[5], 0x02);

	downSemaphore(&usart0_lock);
	transmitBufferUSART0(buffer, 8);
	upSemaphore(&usart0_lock);

        uint16_t start_time = ticks1;
        while( usart0_rx_buffer_length < 4 || (ticks1 - start_time) < AX12MOTOR_REPLY_TIMEOUT )
                asm volatile("nop"::);

	setReplyStatus(REPLY_ON);

} // writeByte
